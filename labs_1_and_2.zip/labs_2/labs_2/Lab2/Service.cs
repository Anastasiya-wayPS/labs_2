using System;

namespace labs_2.Lab2 {
	public class Service {
		public int Id { get; set; }
		public String Name { get; set; }
		public double Price { get; set; }
	}
}
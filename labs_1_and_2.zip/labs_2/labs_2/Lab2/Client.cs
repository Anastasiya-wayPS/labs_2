using System;
using System.Collections.Generic;

namespace labs_2.Lab2 {
	public class Client {
		public int Id { get; set; }
		public String Name { get; set; }
		public Sector Sector { get; set; }
		public String ContactEmail { get; set; }
		public List<Service> Services { get; set; }
	}
}
using System;

namespace labs_2.Lab2 {
	public class History {
		public DateTime ProvidedAt { get; set; }
		public int ClientId { get; set; }
		public int ServiceId { get; set; }
		public int Amount { get; set; }
		public String Consumer { get; set; }
	}
}
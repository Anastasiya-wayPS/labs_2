using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;

namespace labs_2.Lab2 {
	public class Core {
		private List<Client> Clients = new();
		private List<Service> Services = new();
		private List<History> HistoryRecords = new();
		
		public Core() {
			Seed();
		}

		public void Run() {
			Console.WriteLine("Welcome! Please, choose operation: ");
			ListOperations();
		}

		private void ListOperations() {
			try {
				Console.WriteLine("Available operations: \n" 
					+ "1. List clients \n"
					+ "2. List history records \n"
					+ "3. Add service to client\n"
					+ "4. Add record to history \n"
					+ "5. List client services \n"
					+ "\n"
					+ "0. Exit");
				
				String enteredOperation = Console.ReadLine();
				int operation = Convert.ToInt32(enteredOperation);

				switch (operation) {
					case 0:
						return;
					case 1:
						ListClients();
						break;
					case 2:
						ListHistory();
						break;
					case 3:
						AddClientService();
						break;
					case 4:
						AddHistoryRecord();
						break;
					case 5:
						Console.WriteLine("Choose Client: ");
						ListClients();
						Client client = Choose(Clients);
						ListClientServices(client.Id);
						break;
				}
				
				ListOperations();
			}
			catch (Exception ex) {
				Console.WriteLine($"Invalid choise. Try again or choose 0 to exit \n ({ex.Message})");
				ListOperations();
			}
		}

		private void ListHistory() {
			if (HistoryRecords.Count == 0) {
				Console.WriteLine("No operations in system so far");
				return;
			}

			foreach (History history in HistoryRecords) {
				Service service = Services.Find(s => s.Id == history.ServiceId);
				Client client = Clients.Find(c => c.Id == history.ClientId);
				if (service != null && client != null) {
					Console.WriteLine(
					$"[{history.ProvidedAt.ToShortDateString()}] {service.Name} (x{history.Amount}) from {client.Name} for {history.Consumer}");
				}
			}
		}

		private void ListClients() {
			if (Clients.Count == 0) {
				Console.WriteLine("No Clients in system so far");
				return;
			}
			foreach (Client client in Clients) {
				Console.WriteLine($"[{client.Id}] {client.Name} ({client.Sector}) {client.ContactEmail}");
			}
		}

		private void ListClientServices(int clientId) {
			Client client = Clients.Find(c => c.Id == clientId);
			if (client == null) {
				Console.WriteLine($"Client {clientId} not found");
				return;
			}

			if (client.Services.Count == 0) {
				Console.WriteLine("Client provides no services");
				return;
			}

			for (int i = 0; i < client.Services.Count; i++) {
				Service clientService = client.Services[i];
				Console.WriteLine($"[{i}] {clientService.Name} for ${clientService.Price}");
				
			}
		}

		private void AddClientService() {
			Console.WriteLine("Choose Client: ");
			ListClients();
			Client client = Choose(Clients);

			Service newService = NewService();
			client.Services.Add(newService);
			Console.WriteLine($"{newService.Name} added for {client.Name}");
		}

		private Service NewService() {
			try {
				Console.WriteLine("Enter name: ");
				string name = Console.ReadLine();

				Console.WriteLine("Enter price: ");
				string enteredPrice = Console.ReadLine();
				double price = Convert.ToDouble(enteredPrice); 
				return new Service() {
					Id = Services.Count - 1,
					Name = name,
					Price = price,
				};
			}
			catch (Exception ex) {
				Console.WriteLine($"{ex.Message}\n Try again!");
				return NewService();
			}
		}

		private void AddHistoryRecord() {
			Console.WriteLine("Choose Client: ");
			ListClients();
			Client choosenClient = Choose(Clients);

			Console.WriteLine("Choose Service: ");
			ListClientServices(choosenClient.Id);
			Service choosenService = Choose(Services);
			
			Console.WriteLine("Enter amount: ");
			String enteredAmount = Console.ReadLine();
			int amount = Convert.ToInt32(enteredAmount);
			
			Console.WriteLine("Enter Consumer name: ");
			String consumer = Console.ReadLine();

			History record = new() {
				ProvidedAt = new DateTime(),
				Amount = amount,
				ClientId = choosenClient.Id,
				ServiceId = choosenService.Id,
				Consumer = consumer,
			};
			
			HistoryRecords.Add(record);
			Console.WriteLine("Record added to History");
		}

		private T Choose<T>(List<T> list) {
			string entered = Console.ReadLine();
			int idx = Convert.ToInt32(entered);
			if (list.Count < idx && idx > 0 && list[idx] != null) {
				return list[idx];
			}

			throw new Exception("Incorrect choice");
		}
		
		private void Seed() {
			Clients.Add(new()
			{
				Id = 0,
				ContactEmail = "contact@clientA.com",
				Name = "Some cool company",
				Sector = Sector.ECommerce,
			});
			Clients.Add(new() {
				Id = 2,
				ContactEmail = "contact@clientB.com",
				Name = "Other cool company",
				Sector = Sector.Recruting,
			});
			Clients.Add(new() {
				Id = 3,
				ContactEmail = "contact@clientC.com",
				Name = "EA",
				Sector = Sector.IT,
			});
			
			Services.Add(new () {
				Id = 0,
				Name = "Service 1",
				Price = 100,
			});
			Services.Add(new() {
				Id = 1,
				Name = "Service 2",
				Price = 150,
			});
			Services.Add(new() {
				Id = 2,
				Name = "Service 3",
				Price = 175,
			});
			
			HistoryRecords.Add(new () {
				ProvidedAt = new DateTime(),
				Amount = 1,
				ClientId = 0,
				Consumer = "Consumer ABC",
				ServiceId = 1,
			});
			HistoryRecords.Add(new() {
				ProvidedAt = new DateTime(),
				Amount = 20,
				ClientId = 2,
				Consumer = "Dude A",
				ServiceId = 2,
			});
			HistoryRecords.Add(new() {
				ProvidedAt = new DateTime(),
				Amount = 3,
				ClientId = 1,
				Consumer = "Andy",
				ServiceId = 0,
			});
		}
	}
}
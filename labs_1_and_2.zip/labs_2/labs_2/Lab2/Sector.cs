namespace labs_2.Lab2 {
	public enum Sector {
		IT = 0,
		Marketing = 1,
		Recruting = 2,
		ECommerce = 3,
	}
}
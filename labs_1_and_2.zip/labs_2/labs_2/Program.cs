﻿using System;
using labs_2.Lab2;

namespace labs_2 {
	class Program {
		static void Main(string[] args) {
			// Lab1.Run();
			Core lab2 = new Core();
			lab2.Run();
		}
	}
}
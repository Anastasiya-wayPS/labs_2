using System;

namespace labs_2.Lab2 {
	public class Lab1 {
		public static void Run() {
			try {
				Console.WriteLine("Enter numbers count: ");
				string enteredNumbersCount = Console.ReadLine();
				int numbersCount = Convert.ToInt32(enteredNumbersCount);

				double[] enteredNumbers = new double[numbersCount];
				for (int i = 0; i < numbersCount; i++) {
					Console.Write($"Enter number {i + 1}: ");
					string entered = Console.ReadLine();
					double num = Convert.ToDouble(entered);
					enteredNumbers[i] = num;
				}

				Console.WriteLine("Result sequence: ");
				double b = 0;
				for (int i = 0; i < numbersCount; i++) {
					Console.WriteLine(b);
					b += enteredNumbers[i] + i;
				}
			}
			catch (Exception ex) {
				Console.WriteLine(ex.Message);
			}
		}
	}
}
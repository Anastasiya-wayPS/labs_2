﻿using System;

namespace lab_4 {
	class Program {
		static void Main(string[] args) {
			Console.WriteLine("Welcome!");
			Run();
		}

		private static void Run() {
			Console.WriteLine("What to enter: \n"
				+ "1. Book \n"
				+ "2. Magazine \n"
				+ "3. Electronic Resource \n"
				+ "4. Blog \n"
				+ "\n 0.Exit");
			string eOperation = Console.ReadLine();
			bool isValidOperation = Int32.TryParse(eOperation, out int operation);
			if (!isValidOperation) {
				Console.WriteLine($"{eOperation} is not a valid operaton. Try again");
				Run();
			}

			Publication entered = null;
			switch (@operation) {
				case 0:
					return;
				case 1:
					entered = PublicationFactory.Enter<Book>();
					break;
				case 2:
					entered = PublicationFactory.Enter<Book>();
					break;
				case 3:
					entered = PublicationFactory.Enter<Book>();
					break;
				case 4:
					entered = PublicationFactory.Enter<Book>();
					break;
				default:
					entered = PublicationFactory.Enter<Book>();
					break;
			}

			Console.WriteLine(entered.ToString());
			Run();
		}
	}
}
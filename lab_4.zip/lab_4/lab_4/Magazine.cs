using System;

namespace lab_4 {
	public class Magazine: Publication {
		public uint PagesCount { get; set; }
		public uint Edition { get; set; }

		public Magazine(string name, string author, uint pagesCount, uint edition) : base(name, author) {
			PagesCount = pagesCount;
			Edition = edition;
		}

		public override string ToString() {
			return $"{base.ToString()}, {PagesCount} page(-s), Edition {Edition}";
		}
	}
}
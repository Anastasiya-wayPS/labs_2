namespace lab_4 {
	public class Book: Publication {
		public uint Year { get; set; }
		public uint PagesCount { get; set; }
		
		public Book(string name, string author, uint year, uint pagesCount): base(name, author) {
			Year = year;
			PagesCount = pagesCount;
		}

		public override string ToString() {
			return $"{base.ToString()}, {PagesCount} page(-s), {Year}";
		}
	}
}
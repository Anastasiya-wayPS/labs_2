using System;

namespace lab_4 {
	public interface IStringable {
		public String ToString();
	}
}
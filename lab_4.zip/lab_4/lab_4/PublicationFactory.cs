using System;

namespace lab_4 {
	public static class PublicationFactory {
		public static Publication Enter<T>() where T: Publication {
			if (typeof(T) == typeof(Book)) {
				return EnterBook();
			} else if (typeof(T) == typeof(Magazine)) {
				return EnterMagazine();
			} else if (typeof(T) == typeof(EResource)) {
				return EnterEResource();
			} else if (typeof(T) == typeof(Blog)) {
				return EnterBlog();
			}
			
			throw new Exception("Cannot identify Publication type");
		}

		private static Book EnterBook() {
			Console.WriteLine("Enter Name: ");
			string name = Console.ReadLine();
			Console.WriteLine("Enter Author: ");
			string author = Console.ReadLine();
			
			Console.WriteLine("Enter Year: ");
			string eYear = Console.ReadLine();
			uint year = Convert.ToUInt32(eYear);
			Console.WriteLine("Enter Pages count: ");
			string ePages = Console.ReadLine();
			uint pages = Convert.ToUInt32(ePages);

			return new Book(name, author, year, pages);
		}

		private static Magazine EnterMagazine() {
			Console.WriteLine("Enter Name: ");
			string name = Console.ReadLine();
			Console.WriteLine("Enter Author: ");
			string author = Console.ReadLine();

			Console.WriteLine("Enter Pages count: ");
			string ePages = Console.ReadLine();
			uint pages = Convert.ToUInt32(ePages);

			Console.WriteLine("Enter Edition: ");
			string eEdition = Console.ReadLine();
			uint edition = Convert.ToUInt32(eEdition);

			return new Magazine(name, author, pages, edition);
		}

		private static EResource EnterEResource() {
			Console.WriteLine("Enter Name: ");
			string name = Console.ReadLine();
			Console.WriteLine("Enter Author: ");
			string author = Console.ReadLine();
			
			Console.WriteLine("Enter Url: ");
			string url = Console.ReadLine();

			return new EResource(name, author, url);
		}

		private static Blog EnterBlog() {
			EResource eResource = EnterEResource();

			Console.WriteLine("Enter Subscribers count: ");
			string eSubscribers = Console.ReadLine();
			uint subscribers = Convert.ToUInt32(eSubscribers);

			return new Blog(eResource, subscribers);
		}
	}
}
using System;

namespace lab_4 {
	public class EResource: Publication {
		public String Url { get; set; }
		
		public EResource(string name, string author, string url) : base(name, author) {
			Url = url;
		}

		public override string ToString() {
			return $"{base.ToString()} - {Url}";
		}
	}
}
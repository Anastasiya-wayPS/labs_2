using System;

namespace lab_4 {
	public class Publication: IStringable {
		public String Name { get; set; }
		public String Author { get; set; }

		public Publication(string name, string author) {
			Name = name;
			Author = author;
		}

		public override string ToString() {
			return $"{Name}, {Author}";
		}
	}
}
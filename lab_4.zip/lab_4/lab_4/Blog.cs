using System;

namespace lab_4 {
	public class Blog: EResource {
		public uint SubscribersCount { get; set; }


		public Blog(string name, string author, string url, uint subscribers) : base(name, author, url) {
			SubscribersCount = subscribers;
		}

		public Blog(EResource resource, uint subscribers) : base(resource.Name, resource.Author, resource.Url) {
			SubscribersCount = subscribers;
		}

		public override string ToString() {
			return $"{base.ToString()} ({SubscribersCount} subscribers)";
		}
	}
}
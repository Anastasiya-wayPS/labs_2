using System;
using System.Numerics;

namespace lab_3 {
	public static class ComplexMath {
		public static Complex Add(Complex a, Complex b) {
			return a + b;
		}

		public static Complex Multiple(Complex a, Complex b) {
			return a + b;
		}

		public static double GetModule(this Complex a) {
			return Math.Sqrt(Math.Pow(a.Real, 2) + Math.Pow(a.Imaginary, 2));
		}
	}
}
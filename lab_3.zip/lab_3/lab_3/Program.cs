﻿using System;
using System.Numerics;

namespace lab_3 {
	class Program {
		static void Main(string[] args) {
			Run();
		}

		static void Run() {
			Complex number = ReadNumber();
			int operation = ChooseOperation();

			switch (operation) {
				case 1:
					Complex toAdd = ReadNumber();
					Complex additionResult = ComplexMath.Add(number, toAdd);
					Console.WriteLine($"Result: {additionResult}");
					break;
				case 2:
					Complex toMultiple = ReadNumber();
					Complex multipleResult = ComplexMath.Add(number, toMultiple);
					Console.WriteLine($"Result: {multipleResult}");
					break;
				case 3:
					double module = number.GetModule();
					Console.WriteLine($"Result: {module}");
					break;
				case 0:
					return;
			}
		}

		static int ChooseOperation() {
			Console.WriteLine("Choose operation:\n"
			+ "1. Add \n"
			+ "2. Multiple \n"
			+ "3. Get module \n"
			+ "\n"
			+ "0. Exit");

			string entered = Console.ReadLine();
			bool isValidOperation = Int32.TryParse(entered, out int operation);
			if (!isValidOperation) {
				Console.WriteLine($"{entered} is not a valid operation. try again or enter 0 to exit");
				return ChooseOperation();
			}

			return operation;
		}
		
		private static Complex ReadNumber() {
			try {
				Console.WriteLine("Enter complex number (x + yi): ");
				string entered = Console.ReadLine();
				if (entered == null
					|| entered.Trim().Length == 0
					|| !entered.Contains('+')
					|| !entered.Contains('i')) {
					throw new Exception("Invalid complex number");
				}
				string[] parts = entered.Split('+');
				double real = Convert.ToDouble(parts[0].Trim());
				double imaginary = Convert.ToDouble(parts[1].Replace("i", "").Trim());

				Complex number = new(real, imaginary);
				return number;
			}
			catch (Exception ex) {
				Console.WriteLine($"{ex.Message}. Try again");
				return ReadNumber();
			}
		}
	}
}